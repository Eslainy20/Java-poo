public class Arma {
    public Double dano;
    public String tipo;

    public Arma(Double dano, String tipo) {
        this.dano = dano;
        this.tipo = tipo;
    }


}
