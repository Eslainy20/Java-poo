public class Carro {
   public String cor;
   public String modelo;
   public Motor motor;
   public boolean ligado;
   public double velocidade;

    public Carro(String cor, String modelo,  Motor motor,boolean ligado,double velocidade ){
        this.cor= cor;
        this.modelo= modelo;
        this.motor = motor;
        this.ligado = false;
        this.velocidade = 0.0;
    }

    void liga(){
        ligado= true;
        System.out.println("O carro esta ligado!! " +ligado);
    }

    void acelera(Double qtd){
        if(ligado){
            velocidade += qtd;
            System.out.println("O carro esta acelerando" +velocidade+ "km/h");

        }else{
            System.out.println("O carro esta desligado ");
        }

    }

    int pegaMarcha(){
        if(velocidade == 0.0){
            return 0;
        }

        if(velocidade<=20.0){
            return 1;
        }

        if(velocidade<=40.0){
            return 2;
        }

        if(velocidade<= 60.0){
            return 3;
        }

        if(velocidade<=80.0){
            return 4;
        }else{

            return 5;
        }

    }

}
