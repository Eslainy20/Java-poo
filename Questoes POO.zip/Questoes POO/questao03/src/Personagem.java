public class Personagem {
    public String nome;
    public String classe;
    public Arma arma;
    public boolean vivo;
    public double energia;

    public Personagem(String nome, String classe, Arma arma) {
        this.nome = nome;
        this.classe = classe;
        this.arma = arma;
        this.vivo = true;
        this.energia = 100.0;
    }

    public void entrarEmBatalha() {
        System.out.println(nome + " está pronto para a batalha!");
    }

    public void atacar(Double intensidade) {
        if (!vivo) {
            System.out.println(nome + " está morto e não pode atacar.");
            return;
        }
        energia -= intensidade;
        if (energia <= 0) {
            energia = 0;
            vivo = false;
            System.out.println(nome + " atacou com sua " + arma.tipo + " causando " + arma.dano + " de dano, mas ficou exausto e caiu em batalha!");
        } else {
            System.out.println(nome + " atacou com sua " + arma.tipo + " causando " + arma.dano + " de dano.");
        }
    }

    public int nivelDeEnergia() {
        if (energia == 0) return 0;
        else if (energia <= 20) return 1;
        else if (energia <= 40) return 2;
        else if (energia <= 60) return 3;
        else if (energia <= 80) return 4;
        else return 5;
    }


}


