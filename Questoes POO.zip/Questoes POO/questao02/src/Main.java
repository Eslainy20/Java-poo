//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Motor m1 = new Motor(2.5, "Gasolina");
        Carro c1 = new Carro("Branco", "Corola", m1,false,0.0);

        c1.liga();
        c1.acelera(15.0);

        int macha = c1.pegaMarcha();
        System.out.println("Macha atual: " +macha);

        c1.acelera(30.0);
        macha = c1.pegaMarcha();
        System.out.println("Macha atual: " +macha);




    }
    }
