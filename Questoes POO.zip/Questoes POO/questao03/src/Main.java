//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Arma espada = new Arma(35.0, "Espada");

        Personagem guerreiro = new Personagem("Arthur", "Guerreiro", espada);

        guerreiro.entrarEmBatalha();

        guerreiro.atacar(25.0);

        int nivel = guerreiro.nivelDeEnergia();
        System.out.println("Nível de energia de " + guerreiro.nome + ": " + nivel);


    }
    }
