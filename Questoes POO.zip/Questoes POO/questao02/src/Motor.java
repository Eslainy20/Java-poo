public class Motor {
      public double potencia;
      public String tipo;

    public Motor( double potencia, String tipo){
            this.potencia = potencia;
            this.tipo = tipo;
        }

}
